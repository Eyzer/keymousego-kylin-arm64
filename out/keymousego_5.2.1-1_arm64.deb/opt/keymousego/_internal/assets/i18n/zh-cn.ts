<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>Dialog</name>
    <message>
        <location filename="UIFileDialogView.ui" line="14"/>
        <source>File Manage</source>
        <translatorcomment>文件管理</translatorcomment>
        <translation>文件管理</translation>
    </message>
    <message>
        <location filename="UIFileDialogView.ui" line="33"/>
        <source>file name</source>
        <translatorcomment>文件名称</translatorcomment>
        <translation>文件名称</translation>
    </message>
    <message>
        <location filename="UIFileDialogView.ui" line="59"/>
        <source>choice</source>
        <translatorcomment>选择文件</translatorcomment>
        <translation>选择文件</translation>
    </message>
    <message>
        <location filename="UIFileDialogView.ui" line="66"/>
        <source>edit</source>
        <translatorcomment>编辑文件</translatorcomment>
        <translation>编辑文件</translation>
    </message>
    <message>
        <location filename="UIFileDialogView.ui" line="73"/>
        <source>rename</source>
        <translatorcomment>重命名</translatorcomment>
        <translation>重命名</translation>
    </message>
    <message>
        <source>FNF</source>
        <translatorcomment>文件未被找到</translatorcomment>
        <translation>文件未被找到</translation>
    </message>
    <message>
        <source>PINFN</source>
        <translatorcomment>请输入新文件名：</translatorcomment>
        <translation>请输入新文件名：</translation>
    </message>
    <message>
        <source>Success</source>
        <translatorcomment>更新成功</translatorcomment>
        <translation>更新成功</translation>
    </message>
    <message>
        <source>FNCBEOS</source>
        <translatorcomment>文件名不能未空或空格</translatorcomment>
        <translation>文件名不能为空或空格</translation>
    </message>
</context>
<context>
    <name>UIView</name>
    <message>
        <location filename="UIView.ui" line="14"/>
        <source>KeymomuseGo v5.1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="UIView.ui" line="31"/>
        <source>Hotkeys</source>
        <translatorcomment>热键</translatorcomment>
        <translation>热键</translation>
    </message>
    <message>
        <location filename="UIView.ui" line="69"/>
        <source>Terminate</source>
        <translatorcomment>终止录制</translatorcomment>
        <translation>终止录制/执行</translation>
    </message>
    <message>
        <location filename="UIView.ui" line="76"/>
        <source>Language</source>
        <translatorcomment>语言</translatorcomment>
        <translation>语言</translation>
    </message>
    <message>
        <location filename="UIView.ui" line="106"/>
        <source>Record/Pause</source>
        <translatorcomment>开始/暂停录制</translatorcomment>
        <translation>开始/暂停录制</translation>
    </message>
    <message>
        <location filename="UIView.ui" line="123"/>
        <source>Extension</source>
        <translatorcomment>扩展插件</translatorcomment>
        <translation>扩展插件</translation>
    </message>
    <message>
        <location filename="UIView.ui" line="130"/>
        <source>Launch/Pause</source>
        <translatorcomment>开始/暂停执行</translatorcomment>
        <translation>开始/暂停执行</translation>
    </message>
    <message>
        <location filename="UIView.ui" line="158"/>
        <source>Record</source>
        <translatorcomment>开始录制</translatorcomment>
        <translation>开始录制</translation>
    </message>
    <message>
        <location filename="UIView.ui" line="171"/>
        <source>Launch</source>
        <translatorcomment>启动</translatorcomment>
        <translation>启动</translation>
    </message>
    <message>
        <location filename="UIView.ui" line="187"/>
        <source>Pause Record</source>
        <translatorcomment>暂停录制</translatorcomment>
        <translation>暂停录制</translation>
    </message>
    <message>
        <location filename="UIView.ui" line="206"/>
        <source>Ready...</source>
        <translation>就绪...</translation>
    </message>
    <message>
        <location filename="UIView.ui" line="241"/>
        <source>Volume</source>
        <translatorcomment>音量</translatorcomment>
        <translation>音量</translation>
    </message>
    <message>
        <location filename="UIView.ui" line="264"/>
        <source>Config</source>
        <translatorcomment>配置</translatorcomment>
        <translation>配置</translation>
    </message>
    <message>
        <location filename="UIView.ui" line="292"/>
        <source>Mouse precision</source>
        <translatorcomment>鼠标精度</translatorcomment>
        <translation>鼠标精度</translation>
    </message>
    <message>
        <location filename="UIView.ui" line="299"/>
        <source>Running speed(%)</source>
        <translatorcomment>执行速度(%)</translatorcomment>
        <translation>执行速度(%)</translation>
    </message>
    <message>
        <location filename="UIView.ui" line="306"/>
        <source>Run times</source>
        <translatorcomment>执行次数</translatorcomment>
        <translation>执行次数</translation>
    </message>
    <message>
        <location filename="UIView.ui" line="313"/>
        <source>Theme</source>
        <translatorcomment>主题</translatorcomment>
        <translation>主题</translation>
    </message>
    <message>
        <location filename="UIView.ui" line="320"/>
        <source>Script</source>
        <translatorcomment>脚本</translatorcomment>
        <translation>脚本</translation>
    </message>
    <message>
        <location filename="UIView.ui" line="402"/>
        <source>...</source>
        <translation></translation>
    </message>
    <message>
        <source>Finish</source>
        <translatorcomment>结束录制</translatorcomment>
        <translation>结束录制</translation>
    </message>
    <message>
        <source>Continue</source>
        <translatorcomment>继续录制</translatorcomment>
        <translation>继续录制</translation>
    </message>
    <message>
        <source>Pause</source>
        <translatorcomment>暂停录制</translatorcomment>
        <translation>暂停录制</translation>
    </message>
    <message>
        <source>Cursor Position:</source>
        <translatorcomment>光标位置：</translatorcomment>
        <translation>光标位置：</translation>
    </message>
    <message>
        <source>Cursor pos:</source>
        <translatorcomment>光标位置：</translatorcomment>
        <translation>光标位置：</translation>
    </message>
    <message>
        <source>broken</source>
        <translatorcomment>已中断</translatorcomment>
        <translation>已中断</translation>
    </message>
    <message>
        <source>record paused</source>
        <translatorcomment>录制已暂停</translatorcomment>
        <translation>录制已暂停</translation>
    </message>
    <message>
        <source>finished</source>
        <translatorcomment>已完成</translatorcomment>
        <translation>已完成</translation>
    </message>
    <message>
        <source>%d actions recorded</source>
        <translatorcomment>已记录 %d 个动作</translatorcomment>
        <translation>已记录 %d 个动作</translation>
    </message>
    <message>
        <source>running</source>
        <translatorcomment>运行中</translatorcomment>
        <translation>运行中</translation>
    </message>
    <message>
        <source>recorded</source>
        <translatorcomment>已记录</translatorcomment>
        <translation>已记录</translation>
    </message>
    <message>
        <source>%s running..</source>
        <translatorcomment>%s 运行中..</translatorcomment>
        <translation>%s 运行中..</translation>
    </message>
    <message>
        <source>Looptimes</source>
        <translatorcomment>循环次数</translatorcomment>
        <translation>循环次数</translation>
    </message>
    <message>
        <source>script not found, please record first!</source>
        <translatorcomment>未找到脚本，请先录制！</translatorcomment>
        <translation>未找到脚本，请先录制！</translation>
    </message>
    <message>
        <source>An error occurred during execution! Please check logs!</source>
        <translatorcomment>执行过程中发生错误！请检查日志！</translatorcomment>
        <translation>执行过程中发生错误！请检查日志！</translation>
    </message>
    <message>
        <source>An error occurred while parsing script</source>
        <translatorcomment>解析脚本时发生错误</translatorcomment>
        <translation>解析脚本时发生错误</translation>
    </message>
    <message>
        <source>An error occurred during runtime</source>
        <translatorcomment>运行时发生错误</translatorcomment>
        <translation>运行时发生错误</translation>
    </message>
    <message>
        <source>script run failed, please check your log file</source>
        <translatorcomment>脚本执行失败，请检查日志文件</translatorcomment>
        <translation>脚本执行失败，请检查日志文件</translation>
    </message>
    <message>
        <source>An error occurred while calling %s, please check log file</source>
        <translatorcomment>调用 %s 时发生错误，请检查程序日志</translatorcomment>
        <translation>调用 %s 时发生错误，请检查程序日志</translation>
    </message>
</context>
</TS>
