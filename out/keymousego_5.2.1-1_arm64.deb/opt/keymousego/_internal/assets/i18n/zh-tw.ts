<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_TW">
<context>
    <name>Dialog</name>
    <message>
        <location filename="UIFileDialogView.ui" line="14"/>
        <source>File Manage</source>
        <translatorcomment>檔案管理</translatorcomment>
        <translation>檔案管理</translation>
    </message>
    <message>
        <location filename="UIFileDialogView.ui" line="33"/>
        <source>file name</source>
        <translatorcomment>檔案名稱</translatorcomment>
        <translation>檔案名稱</translation>
    </message>
    <message>
        <location filename="UIFileDialogView.ui" line="59"/>
        <source>choice</source>
        <translatorcomment>選擇檔案</translatorcomment>
        <translation>選擇檔案</translation>
    </message>
    <message>
        <location filename="UIFileDialogView.ui" line="66"/>
        <source>edit</source>
        <translatorcomment>編輯檔案</translatorcomment>
        <translation>編輯檔案</translation>
    </message>
    <message>
        <location filename="UIFileDialogView.ui" line="73"/>
        <source>rename</source>
        <translatorcomment>重新命名</translatorcomment>
        <translation>重新命名</translation>
    </message>
    <message>
        <source>FNF</source>
        <translatorcomment>檔案未被找到</translatorcomment>
        <translation>檔案未被找到</translation>
    </message>
    <message>
        <source>PINFN</source>
        <translatorcomment>請輸入新檔案名稱：</translatorcomment>
        <translation>請輸入新檔案名稱：</translation>
    </message>
    <message>
        <source>Success</source>
        <translatorcomment>更新成功</translatorcomment>
        <translation>更新成功</translation>
    </message>
    <message>
        <source>FNCBEOS</source>
        <translatorcomment>檔名不能為空或空格</translatorcomment>
        <translation>檔名不能為空或空格</translation>
    </message>
</context>
<context>
    <name>UIView</name>
    <message>
        <location filename="UIView.ui" line="14"/>
        <source>KeymomuseGo v5.1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="UIView.ui" line="31"/>
        <source>Hotkeys</source>
        <translatorcomment>熱鍵</translatorcomment>
        <translation>熱鍵</translation>
    </message>
    <message>
        <location filename="UIView.ui" line="69"/>
        <source>Terminate</source>
        <translatorcomment>終止錄製</translatorcomment>
        <translation>終止錄製/執行</translation>
    </message>
    <message>
        <location filename="UIView.ui" line="76"/>
        <source>Language</source>
        <translatorcomment>語言</translatorcomment>
        <translation>語言</translation>
    </message>
    <message>
        <location filename="UIView.ui" line="106"/>
        <source>Record/Pause</source>
        <translatorcomment>開始/暫停錄製</translatorcomment>
        <translation>開始/暫停錄製</translation>
    </message>
    <message>
        <location filename="UIView.ui" line="123"/>
        <source>Extension</source>
        <translatorcomment>擴充插件</translatorcomment>
        <translation>擴充插件</translation>
    </message>
    <message>
        <location filename="UIView.ui" line="130"/>
        <source>Launch/Pause</source>
        <translatorcomment>開始/暫停執行</translatorcomment>
        <translation>開始/暫停執行</translation>
    </message>
    <message>
        <location filename="UIView.ui" line="158"/>
        <source>Record</source>
        <translatorcomment>開始錄製</translatorcomment>
        <translation>開始錄製</translation>
    </message>
    <message>
        <location filename="UIView.ui" line="171"/>
        <source>Launch</source>
        <translatorcomment>啟動</translatorcomment>
        <translation>啟動</translation>
    </message>
    <message>
        <location filename="UIView.ui" line="187"/>
        <source>Pause Record</source>
        <translatorcomment>暫停錄製</translatorcomment>
        <translation>暫停錄製</translation>
    </message>
    <message>
        <location filename="UIView.ui" line="206"/>
        <source>Ready...</source>
        <translation>就緒...</translation>
    </message>
    <message>
        <location filename="UIView.ui" line="241"/>
        <source>Volume</source>
        <translatorcomment>音量</translatorcomment>
        <translation>音量</translation>
    </message>
    <message>
        <location filename="UIView.ui" line="264"/>
        <source>Config</source>
        <translatorcomment>配置</translatorcomment>
        <translation>配置</translation>
    </message>
    <message>
        <location filename="UIView.ui" line="292"/>
        <source>Mouse precision</source>
        <translatorcomment>滑鼠精度</translatorcomment>
        <translation>滑鼠精度</translation>
    </message>
    <message>
        <location filename="UIView.ui" line="299"/>
        <source>Running speed(%)</source>
        <translatorcomment>執行速度(%)</translatorcomment>
        <translation>執行速度(%)</translation>
    </message>
    <message>
        <location filename="UIView.ui" line="306"/>
        <source>Run times</source>
        <translatorcomment>執行次數</translatorcomment>
        <translation>執行次數</translation>
    </message>
    <message>
        <location filename="UIView.ui" line="313"/>
        <source>Theme</source>
        <translatorcomment>主題</translatorcomment>
        <translation>主題</translation>
    </message>
    <message>
        <location filename="UIView.ui" line="320"/>
        <source>Script</source>
        <translatorcomment>腳本</translatorcomment>
        <translation>腳本</translation>
    </message>
    <message>
        <location filename="UIView.ui" line="402"/>
        <source>...</source>
        <translation></translation>
    </message>
    <message>
        <source>Finish</source>
        <translatorcomment>結束錄製</translatorcomment>
        <translation>結束錄製</translation>
    </message>
    <message>
        <source>Continue</source>
        <translatorcomment>繼續錄製</translatorcomment>
        <translation>繼續錄製</translation>
    </message>
    <message>
        <source>Pause</source>
        <translatorcomment>暫停錄製</translatorcomment>
        <translation>暫停錄製</translation>
    </message>
    <message>
        <source>Cursor Position:</source>
        <translatorcomment>游標位置：</translatorcomment>
        <translation>游標位置：</translation>
    </message>
    <message>
        <source>Cursor pos:</source>
        <translatorcomment>游標位置：</translatorcomment>
        <translation>游標位置：</translation>
    </message>
    <message>
        <source>broken</source>
        <translatorcomment>已中斷</translatorcomment>
        <translation>已中斷</translation>
    </message>
    <message>
        <source>record paused</source>
        <translatorcomment>錄製已暫停</translatorcomment>
        <translation>錄製已暫停</translation>
    </message>
    <message>
        <source>finished</source>
        <translatorcomment>已完成</translatorcomment>
        <translation>已完成</translation>
    </message>
    <message>
        <source>%d actions recorded</source>
        <translatorcomment>已記錄 %d 個動作</translatorcomment>
        <translation>已記錄 %d 個動作</translation>
    </message>
    <message>
        <source>running</source>
        <translatorcomment>執行中</translatorcomment>
        <translation>執行中</translation>
    </message>
    <message>
        <source>recorded</source>
        <translatorcomment>已記錄</translatorcomment>
        <translation>已記錄</translation>
    </message>
    <message>
        <source>%s running..</source>
        <translatorcomment>%s 執行中..</translatorcomment>
        <translation>%s 執行中..</translation>
    </message>
    <message>
        <source>Looptimes</source>
        <translatorcomment>循環次數</translatorcomment>
        <translation>循環次數</translation>
    </message>
    <message>
        <source>script not found, please record first!</source>
        <translatorcomment>未找到腳本，請先錄製！</translatorcomment>
        <translation>未找到腳本，請先錄製！</translation>
    </message>
    <message>
        <source>An error occurred during execution! Please check logs!</source>
        <translatorcomment>執行過程中發生錯誤！請檢查日誌！</translatorcomment>
        <translation>執行過程中發生錯誤！請檢查日誌！</translation>
    </message>
    <message>
        <source>An error occurred while parsing script</source>
        <translatorcomment>解析腳本時發生錯誤</translatorcomment>
        <translation>解析腳本時發生錯誤</translation>
    </message>
    <message>
        <source>An error occurred during runtime</source>
        <translatorcomment>執行時發生錯誤</translatorcomment>
        <translation>執行時發生錯誤</translation>
    </message>
    <message>
        <source>script run failed, please check your log file</source>
        <translatorcomment>腳本執行失敗，請檢查日誌檔案</translatorcomment>
        <translation>腳本執行失敗，請檢查日誌檔案</translation>
    </message>
    <message>
        <source>An error occurred while calling %s, please check log file</source>
        <translatorcomment>呼叫 %s 時發生錯誤，請檢查程式日誌</translatorcomment>
        <translation>呼叫 %s 時發生錯誤，請檢查程式日誌</translation>
    </message>
</context>
</TS>
